package com.tecnics.config;

import java.io.*;
import java.sql.*;

public class ConfigInsertCsvFile {

	Person person;

	public static void main(String[] args) throws SQLException, IOException {

		processCsvfile();
	}

	public static void processCsvfile() throws SQLException, IOException {
		Connection connection = getDBConnection();

		String csvFilePath = ReadConfigDB.getProperty("csvFilePath");

		try (BufferedReader lineReader = new BufferedReader(new FileReader(csvFilePath))) {
			String lineText = null;
			lineReader.readLine();
			while ((lineText = lineReader.readLine()) != null) {

				String[] data = lineText.split(",");
				String PERSONID = data[0];
				String LASTNAME = data[1];
				String FIRSTNAME = data[2];
				String ADDRESS = data[3];
				String CITY = data[4];

				ConfigInsertCsvFile icf = new ConfigInsertCsvFile();

				Person p = new Person(PERSONID, LASTNAME, FIRSTNAME, ADDRESS, CITY);
				icf.person = p;

				System.out.println(icf.person.toString());
				insertRecord(connection, p);
			}
			connection.close();

		}
	}

	public static Connection getDBConnection() throws SQLException, IOException {
		Connection connection = null;

		String url = ReadConfigDB.getProperty("url");
		String username = ReadConfigDB.getProperty("username");
		String password = ReadConfigDB.getProperty("password");

		connection = DriverManager.getConnection(url, username, password);
		connection.setAutoCommit(false);
		System.out.println("connected");
		return connection;
	}

	public static void insertRecord(Connection connection, Person person) throws SQLException, IOException {
		
		String sqlQuery =ReadConfigDB.getProperty("person_insert_sql");
		
		PreparedStatement statement = connection.prepareStatement(sqlQuery);

		statement.setString(1, person.personId);
		statement.setString(2, person.lastName);
		statement.setString(3, person.firstName);
		statement.setString(4, person.address);
		statement.setString(5, person.city);

		statement.addBatch();

		int count = 0;
		int batchSize = 20;

		if (count % batchSize == 0) {
			statement.executeBatch();

		}

		statement.executeBatch();
		connection.commit();
	}

}
