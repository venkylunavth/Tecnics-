package com.tecnics.config;

	public class Person {
		String personId;
		String lastName;
		String firstName;
		String address;
		String city;
		
	public Person(String personId, String lastName, String firstName, String address, String city) {
		
		this.personId=personId;
		this.lastName=lastName;
		this.firstName=firstName;
		this.address=address;
		this.city=city;
			
		}
	public String getPersonId() {
			return personId;
		}
		public void setPersonId(String personId) {
			this.personId = personId;
		}
		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		@Override
		public String toString() {
			return "Person [personId=" + personId + ", lastName=" + lastName + ", firstName=" + firstName + ", address="
					+ address + ", city=" + city + "]";
		}


	}


