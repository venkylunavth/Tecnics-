package com.org.tecnics;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadConfigFileDB {
	public static void main(String[] args) throws IOException {

		String url = getProperty("url");
		System.out.println(url);
		String username =getProperty("username");
		System.out.println(username);
		String password =getProperty("password");
		System.out.println(password);
		
	}

	public static String getProperty(String key) throws IOException {

		File configFile = new File("configDB.properties");

		FileReader reader = new FileReader(configFile);
		Properties props = new Properties();
		props.load(reader);
		
		String value =props.getProperty(key);
		
		reader.close();
		return value;
		
		

	}

}

