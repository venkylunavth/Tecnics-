package com.org.tecnics;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigFile {
	public static void main(String[] args) {
			File configFile = new File("E:\\read.txt");
	 
	try {
	    FileReader reader = new FileReader(configFile);
	    Properties props = new Properties();
	    props.load(reader);
	 
	    String username = props.getProperty("username");
	 
	    System.out.print("username is: " + username);
	    reader.close();
	} catch (FileNotFoundException ex) {
	    
	} catch (IOException ex) {

	}

	}
}
