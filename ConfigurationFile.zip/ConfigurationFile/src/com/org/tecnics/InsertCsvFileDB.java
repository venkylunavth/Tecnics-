package com.org.tecnics;

	import java.io.*;
	import java.sql.*;

	public class InsertCsvFileDB {

		Person person;
		
		public static void main(String[] args) throws SQLException, IOException {

			ProcessCsvfile();
		}

		public static void ProcessCsvfile() throws SQLException, IOException {
			Connection connection = getDBConnection();
			
			String csvFilePath = "E:\\ReadCSV1.CSV";

			try (BufferedReader lineReader = new BufferedReader(new FileReader(csvFilePath))) {
				String lineText = null;
				lineReader.readLine();
				while ((lineText = lineReader.readLine()) != null) {

					String[] data = lineText.split(",");
					String PERSONID = data[0];
					String LASTNAME = data[1];
					String FIRSTNAME = data[2];
					String ADDRESS = data[3];
					String CITY = data[4];

					InsertCsvFileDB icf = new InsertCsvFileDB();

					Person p = new Person(PERSONID, LASTNAME, FIRSTNAME, ADDRESS, CITY);
					icf.person = p;

					System.out.println(icf.person.toString());
					insertRecord(connection, p);
				}
				connection.close();

			}
		}

		public static Connection getDBConnection() throws SQLException, IOException {
			Connection connection = null;
			
			String url = ReadConfigFileDB.getProperty("url");
			String username=ReadConfigFileDB.getProperty("username");
			String password=ReadConfigFileDB.getProperty("password");

			connection = DriverManager.getConnection(url, username, password);
			connection.setAutoCommit(false);
			System.out.println("connected");
			return connection;
		}

		public static void insertRecord(Connection connection, Person person) throws SQLException {
			String sql = "INSERT INTO TRNGDB.PERSONS(PERSONID, LASTNAME, FIRSTNAME, ADDRESS, CITY) VALUES (?, ?, ?, ?, ? )";
			PreparedStatement statement = connection.prepareStatement(sql);

			statement.setString(1, person.personId);
			statement.setString(2, person.lastName);
			statement.setString(3, person.firstName);
			statement.setString(4, person.address);
			statement.setString(5, person.city);

			statement.addBatch();

			int count = 0;
			int batchSize = 20;

			if (count % batchSize == 0) {
				statement.executeBatch();

			}

			statement.executeBatch();
			connection.commit();
		}

	}


