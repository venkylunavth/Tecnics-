package com.org.tecnics;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class WriteConfigFile {
	public static void main(String[] args) {
		Properties prop = new Properties();

		try {

			prop.setProperty("url", "http://192.168.1.157:9081/wsi/FNCEWS40MTOM");
			prop.setProperty("username", "deadmin");
			prop.setProperty("pasword", "deadmin");

			prop.store(new FileOutputStream("writeConfig.properties"), null);
			System.out.println("done.....");

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}

//E:\\Document\\writeConfig.properties