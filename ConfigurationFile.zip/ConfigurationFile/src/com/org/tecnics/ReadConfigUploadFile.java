package com.org.tecnics;

import java.io.BufferedReader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.security.auth.Subject;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.property.Properties;
import com.filenet.api.util.UserContext;

import com.org.tecnics.ReadConfigUploadFile;

public class ReadConfigUploadFile {

	Document1 document;

	public static void main(String[] args) throws IOException {
		readFile();

	}

	public static void readFile() throws IOException {

		ObjectStore objStore = getObjectStore();

		// Folder folder = getFolder(objStore,document);

		String csvFilePath = "E:\\DocReadFile.CSV";

		try (BufferedReader lineReader = new BufferedReader(new FileReader(csvFilePath))) {
			String lineText = null;

			lineReader.readLine();

			while ((lineText = lineReader.readLine()) != null) {

				System.out.println("--------------1--------------");

				String[] data = lineText.split(",");

				String DocumentClass = data[0];
				String FilenetFolderPath = data[1];
				String DocumentFilePath = data[2];
				String DocumentTitle = data[3];
				String MineType = data[4];
				String FirstName = data[5];
				String LastName = data[6];

				System.out.println("--------------2--------------");

				ReadConfigUploadFile rd = new ReadConfigUploadFile();

				Document1 doc1 = new Document1(DocumentClass, FilenetFolderPath, DocumentFilePath, DocumentTitle,
						MineType, FirstName, LastName);

				rd.document = doc1;
				System.out.println(rd.document.toString());

				Folder folder = getFolder(objStore, FilenetFolderPath);

				uploadDoc(objStore, folder, doc1);

				System.out.println("--------------3--------------");
			}
		}
	}

	public static ObjectStore getObjectStore() throws IOException {

		ObjectStore objStore = null;

		String url = ReadConfigurationFile.getProperty("url");
		String username = ReadConfigurationFile.getProperty("username");
		String password = ReadConfigurationFile.getProperty("password");

		Connection conn = Factory.Connection.getConnection(url);

		Subject subject = UserContext.createSubject(conn, username, password, null);
		UserContext.get().pushSubject(subject);

		Domain domain = Factory.Domain.fetchInstance(conn, null, null);

		objStore = Factory.ObjectStore.fetchInstance(domain, "docs", null);

		System.out.println("--------------4--------------");
		return objStore;

	}

	public static Folder getFolder(ObjectStore objStore, String folderPath) {

		// String folPath = "/RFolder";

		Folder folder = Factory.Folder.fetchInstance(objStore, folderPath, null);

		System.out.println("--------------5--------------");
		return folder;

	}

	@SuppressWarnings("unchecked")
	public static void uploadDoc(ObjectStore objStore, Folder folder, Document1 document) throws FileNotFoundException {

		// String fileName = document.documentTitle;

		FileInputStream fileInput = new FileInputStream(document.documentFilePath);

		Document doc = Factory.Document.createInstance(objStore, document.documentClass);

		System.out.println("--------------6--------------");

		System.out.println("Document Class name" + doc);

		ContentTransfer contentTransfer = Factory.ContentTransfer.createInstance();

		contentTransfer.setCaptureSource(fileInput);

		ContentElementList contentElementList = Factory.ContentElement.createList();

		contentElementList.add(contentTransfer);

		doc.set_ContentElements(contentElementList);

		System.out.println("--------------7--------------");

		contentTransfer.set_RetrievalName(document.documentTitle);

		System.out.println("FileName:" + document.documentTitle);

		doc.set_MimeType(document.mineType);

		System.out.println("--------------8--------------");

		Properties p = doc.getProperties();

		p.putValue("DocumentTitle", document.documentTitle);
		p.putValue("N_FirstName", document.firstName);
		p.putValue("N_LastName", document.lastName);

		doc.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
		doc.save(RefreshMode.REFRESH);

		System.out.println("--------------9--------------");

		String documentName = "" + document.documentTitle + document.mineType;

		ReferentialContainmentRelationship rc = folder.file(doc, AutoUniqueName.AUTO_UNIQUE, documentName,
				DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);

		rc.save(RefreshMode.REFRESH);

		System.out.println("----------");
	}

}
