package com.org.tecnics;

public class Document1 {

	String documentClass;
	String filenetFolderPath;
	String documentFilePath;
	String documentTitle;
	String mineType;
	String firstName;
	String lastName;

	public Document1(String DocumentClass, String FilenetFolderPath, String DocumentFilePath, String DocumentTitle,
			String MineType, String FirstName, String LastName) {

		this.documentClass = DocumentClass;
		this.filenetFolderPath = FilenetFolderPath;
		this.documentFilePath = DocumentFilePath;
		this.documentTitle = DocumentTitle;
		this.mineType = MineType;
		this.firstName = FirstName;
		this.lastName = LastName;

	}


	public String getDocumentClass() {
		return documentClass;
	}

	public void setDocumentClass(String documentClass) {
		this.documentClass = documentClass;
	}

	public String getFilenetFolderPath() {
		return filenetFolderPath;
	}

	public void setFilenetFolderPath(String filenetFolderPath) {
		this.filenetFolderPath = filenetFolderPath;
	}

	public String getMineType() {
		return mineType;
	}

	public void setMineType(String mineType) {
		this.mineType = mineType;
	}

	public String getDocumentFilePath() {
		return documentClass;
	}

	public void setDocumentFilePath(String documentFilePath) {
		this.documentClass = documentFilePath;
	}

	public String getFolderFilePath() {
		return filenetFolderPath;
	}

	public void setFolderFilePath(String folderFilePath) {
		this.filenetFolderPath = folderFilePath;
	}

	public String getDocumentTitle() {
		return documentFilePath;
	}

	public void setDocumentTitle(String documentTitle) {
		this.documentFilePath = documentTitle;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Document1 [documentClass=" + documentClass + ", filenetFolderPath=" + filenetFolderPath
				+ ", documentFilePath=" + documentFilePath + ", documentTitle=" + documentTitle + ", mineType="
				+ mineType + ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}

	

}
