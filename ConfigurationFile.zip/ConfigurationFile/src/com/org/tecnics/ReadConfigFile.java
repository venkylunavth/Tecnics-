package com.org.tecnics;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadConfigFile {
	public static void main(String[] args) {
		configFile();
	}
		public static void configFile() {
	
		File configFile = new File("config.properties");

		try {
			FileReader reader = new FileReader(configFile);
			Properties props = new Properties();
			props.load(reader);

			String url = props.getProperty("url");
			String username =props.getProperty("username");
			String password =props.getProperty("password");

			System.out.println("url is: " + url);
			System.out.println("username is: " + username);
			System.out.println("password is: " + password);
			
			reader.close();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
