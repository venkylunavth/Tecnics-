package com.example.demo.Controller;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.aspectj.weaver.NewConstructorTypeMunger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.Management;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.EmployeeDao.Employee;
import com.example.demo.EmployeeDao.LeaveManagement;
import com.example.demo.EmployeeDao.Payslip;
import com.example.demo.EmployeeDao.User;
import com.example.demo.EmployeeService.EmployeeService;
import com.example.demo.EmployeeService.ManagementServices;
import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.Repository.LeaveRepository;
import com.example.demo.Repository.PayslipRepository;
import com.example.demo.Repository.UserRepository;

import com.example.demo.Repository.UserRepository;

@Controller
public class MainController {
	@Autowired
	EmployeeService userService;

	@Autowired
	EmployeeRepository repo;

	@Autowired
	UserRepository userRepository;

	@Autowired
	LeaveRepository repository;

	@Autowired
	ManagementServices service;

	@Autowired
	PayslipRepository payrepo;
	
	
	@GetMapping("/leaveform")
	public String getform() {
		return "leaves";
	}

	@PostMapping("/applyleave")
	public String createEmployee(LeaveManagement emp) {
		System.out.println("leaveform" + emp.getId());
		service.insertdata(emp);
		return "leaves";

	}

	@PostMapping("/register")
	public String insertData(User user) {
		userService.save(user);
		return "login";
	}
	  @PostMapping("/login") public String
	  getUserByEmpidPassword( @RequestParam("empid") int empid,@RequestParam("password") String password,HttpServletResponse response)
	  { 
		  User user=userRepository.findData(empid, password); 
		  String empid1= String.valueOf( user.getEmpid()); 
		  Cookie cookie=new Cookie("empid",empid1);
	      response.addCookie(cookie);
	      if(user == null) { 
		  return "login"; 
          }
	      else 
	      { 
		  return "dashboard"; 
		  } 
	  }
	 
	@GetMapping("/profiles")
	public ModelAndView getByEmpid(@CookieValue(name = "empid") String empid1) {
		int empid = Integer.parseInt(empid1);
		ModelAndView mv = new ModelAndView("profile");
		Employee emp = repo.findByEmpid(empid);
		mv.addObject("emp", emp);
		System.out.println("emp" + emp);
//		mv.addObject("emp", emp);
//		System.out.println(emp);
		return mv;
	}
	
	@GetMapping("/payslips")
	public ModelAndView getData(@CookieValue(name= "empid")String empid1) {
		
		int empid = Integer.parseInt(empid1);
		ModelAndView mv = new ModelAndView("payslips");
		Payslip ps  =   payrepo.findData(empid);
		mv.addObject("ps", ps);
		return mv;
		
	}
	
	
	
	@GetMapping("/Employee")
	public String viewHomePage() {
		return "index";
	}

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());

		return "signupform";
	}

	@PostMapping("/signupform")
	public String show(Model model) {
		model.addAttribute("user", new User());

		return "/login";
	}

	@GetMapping("/login")
	public String showlogin(Model model) {
		model.addAttribute("user", new User());

		return "login";
	}

	@GetMapping("/profile")
	public String showprofile(Model model) {
		model.addAttribute("user", new User());

		return "profile";
	}

	@GetMapping("/dashboard")
	public String dashboard(Model model) {
		model.addAttribute("user", new User());

		return "dashboard";
	}

	@GetMapping("/calender")
	public String calender(Model model) {
		model.addAttribute("user", new User());

		return "calender";
	}

//	@GetMapping("/payslips")
//	public String payslips(Model model) {
//		model.addAttribute("user", new User());
//
//		return "payslips";
//	}

	@GetMapping("/Aboutus")
	public String aboutus(Model model) {
		model.addAttribute("user", new User());

		return "Aboutus";
	}

	@GetMapping("/Hrpolices")
	public String policy(Model model) {
		model.addAttribute("user", new User());

		return "Hrpolices";
	}

}
