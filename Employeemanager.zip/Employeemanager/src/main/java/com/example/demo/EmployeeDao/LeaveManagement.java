package com.example.demo.EmployeeDao;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


@Entity
@Table(name = "newtable")
public class LeaveManagement {
	

     @Id
     @Column(name="id")
     private Integer id;
   

	@Column(name="fromdate")
	private String fromdate;

	@Column(name="todate")
	private String todate;
	
	@Column(name="leavetype")
	private String leavetype;
	
	@Column(name="reason")
	private String reason;
	
	public LeaveManagement() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFromdate() {
		return fromdate;
	}

	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

	public String getTodate() {
		return todate;
	}

	public void setTodate(String todate) {
		this.todate = todate;
	}

	public String getLeavetype() {
		return leavetype;
	}

	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "LeaveManagement [id=" + id + ", fromdate=" + fromdate + ", todate=" + todate + ", leavetype="
				+ leavetype + ", reason=" + reason + "]";
	}

	public LeaveManagement(int id, String fromdate, String todate, String leavetype, String reason) {
		super();
		this.id = id;
		this.fromdate = fromdate;
		this.todate = todate;
		this.leavetype = leavetype;
		this.reason = reason;
	}

	

	
	



}
