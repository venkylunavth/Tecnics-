package com.example.demo.EmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.EmployeeDao.LeaveManagement;
import com.example.demo.Repository.LeaveRepository;
@Service
public class ManagementServices {
	@Autowired
	private  LeaveRepository emprepo;

		public void insertdata(LeaveManagement  emp) {
		     emprepo.save(emp);	
		}
	}
	

