package com.example.demo.EmployeeService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.EmployeeDao.Employee;
import com.example.demo.EmployeeDao.LeaveManagement;
import com.example.demo.EmployeeDao.Login;
import com.example.demo.EmployeeDao.User;
import com.example.demo.Repository.EmployeeRepository;
//import com.example.demo.Repository.LeaveManageRepository;
import com.example.demo.Repository.LeaveRepository;
import com.example.demo.Repository.UserRepository;

@Service
public class EmployeeService {
	
	@Autowired
	UserRepository emprepo;
	


@Autowired
EmployeeRepository repo;

    
	
	public void save(User user)
	{
		emprepo.save(user);
		
	}


	public User findprofile(int empid,String password)
	{
		User user= emprepo.findData(empid, password);
		return user;
		
	}
	



	

}

	
	


