package com.tecnic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tecnics.pojo.User;

public class UserDetails {
	
	public static Connection getConnection() {
		
		Connection connection = null;
		try {
			Class.forName(ConfigFile.getProperty("DB2_Driver"));
			connection = DriverManager.getConnection(ConfigFile.getProperty("url"),ConfigFile.getProperty("username") ,ConfigFile.getProperty("password"));
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}

	public static int insert(User u) {
		int status = 0;
		try {
			Connection connection = UserDetails.getConnection();
			PreparedStatement prestmt = connection.prepareStatement(ConfigFile.getProperty("Insert_Data"));
			prestmt.setString(1, u.getName());
			prestmt.setString(2, u.getEmail());
			prestmt.setString(3, u.getCountry());
			

			status = prestmt.executeUpdate();

			connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}

	public static int update(User u) {
		int status = 0;
		try {
			Connection connection = UserDetails.getConnection();
			PreparedStatement prestmt = connection.prepareStatement(ConfigFile.getProperty("Update_Data"));
			prestmt.setString(1, u.getName());
			prestmt.setString(2, u.getEmail());
			prestmt.setString(3, u.getCountry());
			prestmt.setInt(4, u.getId());

			status = prestmt.executeUpdate();

			connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}

	public static int delete(User u) {
		int status = 0;
		try {
			Connection connection = UserDetails.getConnection();
			PreparedStatement prestmt = connection.prepareStatement(ConfigFile.getProperty("Delete_Data"));
			prestmt.setInt(1, u.getId());
			status = prestmt.executeUpdate();

			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return status;
	}

	public static User getUserDataById(int id) {
		User u = new User();

		try {
			Connection connection = UserDetails.getConnection();
			PreparedStatement ps = connection.prepareStatement(ConfigFile.getProperty("GetById_Data"));
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setCountry(rs.getString(4));
				
			}
			connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}

	public static List<User> getAllUsersData() {
		List<User> list = new ArrayList<User>();

		try {
			Connection connection = UserDetails.getConnection();
			PreparedStatement prestmt = connection.prepareStatement(ConfigFile.getProperty("GetAll_Data"));
			ResultSet rs = prestmt.executeQuery();
			while (rs.next()) {
				User u = new User();
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setCountry(rs.getString(4));
				list.add(u);
			}
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}


