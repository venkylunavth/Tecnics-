package com.ocs.controller;

import java.util.Optional;

import com.ocs.Entity.Patient;
import com.ocs.repo.resgistrationRepo;
import com.ocs.service.registrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpSession;

@Controller
public class PatientController {

	@Autowired
	private registrationService regService;

	@Autowired
	private resgistrationRepo repo;
	
	
	
	
	
	
	
	//*****************************************
	
	//login logout
	@PostMapping("/login")
	public String login_user(@RequestParam("pname") String pname,@RequestParam("pass") String pass,HttpSession session,ModelMap modelMap)
			
	{
		
	Patient auser=repo.findByPnamePass(pname, pass);
	
	if(auser!=null)
	{
		String uname=auser.getPname();
		String upass=auser.getPass();
	
		//pname-form
		if(pname.equalsIgnoreCase(uname) && pass.equalsIgnoreCase(upass)) 
		{
			session.setAttribute("pname",pname);
			return "dummy";//
		}
		else 
		{
			modelMap.put("error", "Invalid Account");
			return "login";
		}
	}
	else
	{
		modelMap.put("error", "Invalid Account");
		return "login";
	}
	
	}
	
	//logout
	@GetMapping(value = "/logout")
	public String logout_user(HttpSession session)
	{
		session.removeAttribute("pname");
		session.invalidate();
		return "login";
	}
	
	
	//*****************************************************************
	
	
	
	
	
	
	
	
	
	
	
	

	// @RequestMapping(value = "/save",method = RequestMethod.POST)
	@PostMapping("/save")
	public String insertData(Patient patient) {
		regService.save(patient);
		return "success";
	}

	@PostMapping("/delete")
	public String deleteData(@RequestParam("pid") int pid) {
		regService.deletePatientData(pid);
		return "index";
	}

	// registration Page
	@RequestMapping("/r") //routing
	public String viewRegisterPage() {
		return "register";
	}

	// view Page
	@RequestMapping("/vp")
	public String viewPatientPage() {
		return "view";
	}

	@RequestMapping("/dp")
	public String deletePage() {
		return "delete";
	}

	@RequestMapping("/e")
	public String editPage() {
		return "edit";
	}

	// Doctors Registration
	@RequestMapping("/d")
	public String doctorsRegisterPage() {
		return "doctors";
	}

	// Login Page
	@RequestMapping("/l")
	public String viewLoginPage() {
		return "login";
	}

	@RequestMapping("/")
	public String viewHomePage() {
		return "index";
	}

	// GetMapping
	/*
	 * @GetMapping("/{pid}") public Optional<Patient>
	 * getPatient(@PathVariable("pid")int pid) {
	 * 
	 * return regService.getPatient(pid);
	 * 
	 * }
	 */

	@PostMapping("/getbypid")
	public ModelAndView getPatient1(@RequestParam("pid") int pid) {

		ModelAndView mv = new ModelAndView("view");
		Patient empdao = regService.findByPid(pid).orElseThrow(null);

		mv.addObject("empdao", empdao);
		return mv;
	}

	// edit
	/*
	 * @PostMapping("/getbypid1") public ModelAndView getPatient2(int pid1,Patient
	 * patient) { ModelAndView mv=new ModelAndView("edit"); Patient
	 * empdao=regService.findByPid(pid1).orElseThrow(null);
	 * 
	 * mv.addObject("empdao", empdao); regService.updatePatient(pid1, patient);
	 * return mv; }
	 */
	@PostMapping("/getbypid2")
	public ModelAndView UpdatePatient(int pid) {
		Patient empdao = regService.findByPid(pid).orElseThrow(null);
		ModelAndView mv = new ModelAndView("edit");

		mv.addObject("empdao", empdao);
		return mv;
	}

	@PostMapping("/update")
	public String updatePatient( Patient patient) {
		// int p1=patient.getPid();
        regService.updatePatient(patient);
		return "index";
	}

}
