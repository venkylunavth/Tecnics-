package com.ocs.controller;

import com.ocs.Entity.Doctors;
import com.ocs.service.DoctorsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;



@Controller
public class DoctorsController {
	
	@Autowired
	private DoctorsService dservice;
	
	@PostMapping("/saved")
	public String registerDoctor( Doctors doctors) {
		
		dservice.saveDoctors(doctors);
		
		return "login";
	}

}
