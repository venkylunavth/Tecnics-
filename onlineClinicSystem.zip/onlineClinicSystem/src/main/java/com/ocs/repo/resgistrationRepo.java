package com.ocs.repo;

import com.ocs.Entity.Patient;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface resgistrationRepo extends JpaRepository<Patient, Integer>{
	
	@Query("from Patient where pname=?1 and pass=?2")
	public Patient findByPnamePass(String pname,String pass);

}
