package com.ocs.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;




//@Table(name="patient")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
public class Patient {
	

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
    private	int pid;
	private	String pname;
	private String pass;
	private String contact;
	private String city;
	private String district;
	private String state;
	private String country;
	private String pcode;
	
	
	
	

}
