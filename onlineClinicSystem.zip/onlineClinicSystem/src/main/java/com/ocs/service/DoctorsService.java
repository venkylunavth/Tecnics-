package com.ocs.service;

import com.ocs.Entity.Doctors;
import com.ocs.repo.DoctorsRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DoctorsService {
	
	@Autowired
	private DoctorsRepository drepo;
	
	public Doctors saveDoctors(Doctors doctors) {
		
		return drepo.save(doctors);
		
		
	}

}
