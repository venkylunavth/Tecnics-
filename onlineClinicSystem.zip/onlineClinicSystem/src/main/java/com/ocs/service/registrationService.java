package com.ocs.service;


import java.util.Optional;
import com.ocs.Entity.Patient;
import com.ocs.repo.resgistrationRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class registrationService {
	
	@Autowired
	private resgistrationRepo repo; 
	
	
	
	
	
	
	public Patient save(Patient patient)
	{
		return repo.save(patient);
		
	}
	
	//get single emp detail
	 public Optional<Patient> getPatient(int pid) {
		 return  repo.findById(pid);
		 
	 }

	public Optional<Patient> findByPid(int pid) {
		Optional<Patient> op=repo.findById(pid);
		return op;
	}

	public void deletePatientData(int pid) {
		// TODO Auto-generated method stub
		repo.deleteById(pid);
		
	}

	  public Patient updatePatient( Patient patient) {
	    
	    int pId=patient.getPid();
	    Patient p=repo.getById(pId);
	    p.setPname(patient.getPname());
	    p.setCity(patient.getCity());
	    p.setContact(patient.getContact());
	    p.setDistrict(patient.getDistrict());
	    
		 return repo.save(p); 
		 }
		

}
