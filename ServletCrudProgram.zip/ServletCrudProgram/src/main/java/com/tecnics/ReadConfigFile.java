 package com.tecnics;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadConfigFile {
	
	static Properties props;
	static FileReader reader;
	static {
		File configFile = new File("E:\\config.properties");

		try {
			reader = new FileReader(configFile);
			props = new Properties();
			props.load(reader);
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	
	}
	public static String getProperty(String key) throws IOException {
		
		String value = props.getProperty(key);
		reader.close();
		return value;

	}
}
