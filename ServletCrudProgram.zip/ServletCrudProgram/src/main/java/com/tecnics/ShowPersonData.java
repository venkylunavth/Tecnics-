package com.tecnics;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShowPersonData
 */
@WebServlet("/ShowPersonData")
public class ShowPersonData extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowPersonData() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<a href='Insert.html' style='color:black'>Add New Person Data</a>");
		out.println("<h1 style='margin-left: 400px'>Person Details List</h1>");
		List<Person> list = PersonDetails.getAllPersonsData();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset=\"utf-8\">");
		out.println("<title>Persons Details</title>");
		out.println("<style>");
		out.println("body {");
		out.println("background-color: linen;");
		out.println("}");
		out.println("table {");

		out.println("color:black;");
		out.println("background-color:white;");
		out.println("text-align: center;");
		out.println("margin-left: 40px");
		out.println("}");
		out.println("#table-scroll {");
		out.println("height:500px;");
		out.println("overflow:auto;");
		out.println("margin-top:20px;");
		out.println("}");
		out.println("</style>");
		out.println("</head>");
		out.println("<body>");

		out.print("<div id='table-scroll'>");

		out.print("<table class='table'  border='1' width='80%'");
		out.print(
				"<th><tr><th>Person ID</th><th>LastName</th><th>FirstName</th><th>Address</th><th>City</th><th>Update</th><th>Delete</th></tr>");
		for (Person p : list) {
			out.print("<tr><td>" + p.getPersonID() + "</td><td>" + p.getLastName() + "</td><td>" + p.getFirstName()
					+ "</td><td>" + p.getAddress() + "</td><td>" + p.getCity()
					+ "</td><td><a href='UpdateDetails?personID=" + p.getPersonID()
					+ "'>update</a></td>  <td><a href='DeleteDetails?personID=" + p.getPersonID()
					+ "'>delete</a></td></tr>");
			
			out.print("</div>");
			out.println("</body>");
			out.println("</html>");

		}

	}

}
