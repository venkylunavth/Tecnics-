package com.tecnic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tecnics.pojo.Person;

public class PersonDetails {
	
	public static Connection getConnection() {
		
		Connection connection = null;
		try {
			Class.forName(ConfigFile.getProperty("DB2_Driver"));
			connection = DriverManager.getConnection(ConfigFile.getProperty("url"),ConfigFile.getProperty("username") ,ConfigFile.getProperty("password"));
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}

	public static int insert(Person p) {
		int status = 0;
		try {
			Connection connection = PersonDetails.getConnection();
			PreparedStatement prestmt = connection.prepareStatement(ConfigFile.getProperty("Insert_Data"));
			prestmt.setInt(1, p.getPersonID());
			prestmt.setString(2, p.getLastName());
			prestmt.setString(3, p.getFirstName());
			prestmt.setString(4, p.getAddress());
			prestmt.setString(5, p.getCity());

			status = prestmt.executeUpdate();

			connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}

	public static int update(Person p) {
		int status = 0;
		try {
			Connection connection = PersonDetails.getConnection();
			PreparedStatement prestmt = connection.prepareStatement(ConfigFile.getProperty("Update_Data"));
			prestmt.setString(1, p.getLastName());
			prestmt.setString(2, p.getFirstName());
			prestmt.setString(3, p.getAddress());
			prestmt.setString(4, p.getCity());
			prestmt.setInt(5, p.getPersonID());

			status = prestmt.executeUpdate();

			connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}

	public static int delete(Person p) {
		int status = 0;
		try {
			Connection connection = PersonDetails.getConnection();
			PreparedStatement prestmt = connection.prepareStatement(ConfigFile.getProperty("Delete_Data"));
			prestmt.setInt(1, p.getPersonID());
			status = prestmt.executeUpdate();

			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return status;
	}

	public static Person getPersonDataById(int personID) {
		Person p = new Person();

		try {
			Connection connection = PersonDetails.getConnection();
			PreparedStatement ps = connection.prepareStatement(ConfigFile.getProperty("GetById_Data"));
			ps.setInt(1, personID);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				p.setPersonID(rs.getInt(1));
				p.setLastName(rs.getString(2));
				p.setFirstName(rs.getString(3));
				p.setAddress(rs.getString(4));
				p.setCity(rs.getString(5));

			}
			connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return p;
	}

	public static List<Person> getAllPersonsData() {
		List<Person> list = new ArrayList<Person>();

		try {
			Connection connection = PersonDetails.getConnection();
			PreparedStatement prestmt = connection.prepareStatement(ConfigFile.getProperty("GetAll_Data"));
			ResultSet rs = prestmt.executeQuery();
			while (rs.next()) {
				Person p = new Person();
				p.setPersonID(rs.getInt(1));
				p.setLastName(rs.getString(2));
				p.setFirstName(rs.getString(3));
				p.setAddress(rs.getString(4));
				p.setCity(rs.getString(5));
				list.add(p);
			}
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}

