package com.tecnics;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EmployeeDetails extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		response.setContentType("text/html;charset=UTF-8");

		Connection connection;
		try {
			connection = getConnection();
			getEmployeeDetails(connection, out);
		} catch (SQLException e) {

			e.printStackTrace();
		} catch (JSONException e) {

			e.printStackTrace();
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}

	}

	public static Connection getConnection() throws SQLException, ClassNotFoundException {

		Connection connection = null;
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		String url = "jdbc:db2://192.168.1.149:50000/TRNGDB";
		String username = "db2admin";
		String password = "Password1";

		connection = DriverManager.getConnection(url, username, password);
		System.out.println("Connected to database.");
		return connection;

	}

	public static void getEmployeeDetails(Connection connection, PrintWriter out) throws SQLException, JSONException {
		
		String sql = "SELECT * FROM TRNGDB.EMPLOYEE ";
		     PreparedStatement pre=connection.prepareStatement(sql);
		ResultSet resultSet = pre.executeQuery();


		JSONArray jsonarr = new JSONArray();
       
		int count = 0;
		while (resultSet.next()) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("SNO", resultSet.getString(1));
			jsonObject.put("EMPID",resultSet.getString(2));
			jsonObject.put("FIRSTNAME",resultSet.getString(3));
			jsonObject.put("LASTNAME",resultSet.getString(4));

			jsonarr.put(jsonObject);

		}
		
		out.print(jsonarr);
		
		connection.close();
	}

}
