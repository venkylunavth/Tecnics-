package com.tecnics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PutData extends HttpServlet{
	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println("------------");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Connection connection = null;
		System.out.println("-----------1-------");
		try {
			Class.forName("com.ibm.db2.jcc.DB2Driver");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		System.out.println("-----------2-------");
		String url = "jdbc:db2://192.168.1.149:50000/TRNGDB";
		String username = "db2admin";
		String password = "Password1";
		System.out.println("-----------3-------");
		try {
			connection = DriverManager.getConnection(url, username, password);

			System.out.println("Connected to database.");
			 if(request.getParameter("choise")==null) {
			String sql = "UPDATE TRNGDB.PERSONS SET LASTNAME='SHAIK',FIRSTNAME ='NAZMA' WHERE PERSONID = 1";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.executeUpdate(sql);
			 }
			out.println("updated successfully");
			System.out.println("updated successfully");
			connection.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
}

