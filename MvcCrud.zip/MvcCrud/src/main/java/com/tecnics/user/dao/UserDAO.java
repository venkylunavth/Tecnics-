package com.tecnics.user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tecnics.model.User;

public class UserDAO {
	
	public static Connection getConnection() {
		
		Connection connection = null;
		try {
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			connection = DriverManager.getConnection("jdbc:db2://192.168.1.149:50000/TRNGDB","db2admin" ,"Password1");
		} catch (Exception e) {
			System.out.println(e);
		}
		return connection;
	}

	public static int insertUser(User u) {
		int status = 0;
		try {
			Connection connection = UserDAO.getConnection();
			PreparedStatement prestmt = connection.prepareStatement("INSERT INTO TRNGDB.USERS( NAME, EMAIL, COUNTRY ) VALUES ( ?, ?, ?)");
		//	prestmt.setInt(1, u.getId());
			prestmt.setString(1, u.getName());
			prestmt.setString(2, u.getEmail());
			prestmt.setString(3, u.getCountry());
			

			status = prestmt.executeUpdate();

			//connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}

	public static int updateUser(User u) {
		int status = 0;
		try {
			Connection connection = UserDAO.getConnection();
			PreparedStatement prestmt = connection.prepareStatement("UPDATE TRNGDB.USERS SET NAME = ?,EMAIL = ?,COUNTRY = ? WHERE ID = ?");
			prestmt.setString(1, u.getName());
			prestmt.setString(2, u.getEmail());
			prestmt.setString(3, u.getCountry());
			prestmt.setInt(4, u.getId());

			status = prestmt.executeUpdate();

			//connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}

	public static int deleteUser(int id) {
		int status = 0;
		try {
			Connection connection = UserDAO.getConnection();
			PreparedStatement prestmt = connection.prepareStatement("DELETE FROM TRNGDB.USERS WHERE ID = ?");
			prestmt.setInt(1, id);
			status = prestmt.executeUpdate();

			//connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return status;
	}

	public static User selectUser(int id) {
		User u = new User();

		try {
			Connection connection = UserDAO.getConnection();
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM TRNGDB.USERS WHERE ID = ?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setCountry(rs.getString(4));
				
			}
			//connection.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return u;
	}

	public static List<User> selectAllUsers() {
		List<User> list = new ArrayList<User>();

		try {
			Connection connection = UserDAO.getConnection();
	
			PreparedStatement prestmt = connection.prepareStatement("SELECT * FROM TRNGDB.USERS");
			ResultSet rs = prestmt.executeQuery();
	
			while (rs.next()) {
				
				User u = new User();
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setCountry(rs.getString(4));
				list.add(u);
			
			}
		
			//connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}


