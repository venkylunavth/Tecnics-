package com.example.demo.controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
//import javax.validation.Valid;
//import com.example.demo.model.Employee;
//import com.example.demo.service.EmpService;
//import org.springframework.stereotype.Repository;
//import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.model.Employee;


@Controller
public class JspController {
	@Autowired
	EmployeeRepository emprepo;
	
	
	
    @RequestMapping("/home")
	public ModelAndView home() {
		ModelAndView mv=new ModelAndView("home");
		return mv;
	
	}
    
    
   
   // @PostMapping("/getbyid") -- changed
    @PostMapping("/{getbyid}")
    public ModelAndView getdata(@RequestParam("empId") int empId)
    {
    ModelAndView mv=new ModelAndView("viewdata");
    Employee empdao=emprepo.findById(empId).orElse(null);
    mv.addObject("empdao", empdao);
    return mv;
    }
   
    
   @PostMapping("/getbyname")
    public ModelAndView getdata2(@RequestParam("empName") String empName)
    {
    	ModelAndView mv= new ModelAndView("viewdata2");
    	
		Employee empdao2=(Employee) emprepo.findByEmpName(empName);
    	mv.addObject("empdao2", empdao2);
    	return mv;
    }
  
   @PostMapping("/getbymail")
  public ModelAndView getdata3(@RequestParam ("empMail") String empMail)
  {
    ModelAndView mv = new ModelAndView("viewdata3");
    Employee empdao3 =(Employee)emprepo.findByEmpMail(empMail);
    mv.addObject("empdao3", empdao3);
    return mv;
  }
   
   @PostMapping("/getbyphn")
   public ModelAndView getdata4(@RequestParam ("empPhn") String empPhn) {
	   ModelAndView mv = new ModelAndView("viewdata4");
	   Employee empdao4 = (Employee)emprepo.findByEmpPhn(empPhn); 
	   mv.addObject("empdao4", empdao4);
	   return mv;
   }
    
   @PostMapping("/getbydept")
   public ModelAndView getdata5(@RequestParam("dept")String dept)
   {
	   ModelAndView mv=new ModelAndView("viewdata5");
	   Employee empdao5 = (Employee) emprepo.findByDept(dept) ;
	    mv.addObject("empdao5", empdao5);
	    return mv;
   }
}
 