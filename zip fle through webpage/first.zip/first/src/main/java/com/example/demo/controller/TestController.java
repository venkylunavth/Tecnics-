package com.example.demo.controller;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmpService;

// @RequestMapping("/")
@Controller
public class TestController {
	
		@Autowired
		EmpService empService1;
		
		/*@PostMapping("/getbyname")
		public ModelAndView getdata(@RequestParam("emp_name") String emp_name)
		{
			ModelAndView mv=new ModelAndView("viewpage");
			Employee empdao2=empService1.findbyname(emp_name);
	    	mv.addObject("empdao2", empdao2);
	    	return mv;
		}*/
		
		
		@GetMapping("/getbyid/{empId}")
		public Optional<Employee> getEmployee( @PathVariable Integer empId) {
			
			return empService1.getEmployee(empId);
		}
		
		
		@GetMapping("/employees")
		public List<Employee> getEmployee() {
			
			return empService1.getEmployees();
		}

		@PostMapping("/create")
		public String creatEmployee( Employee emp) {
			empService1.createEmployee(emp);
			return "home";
		}
		
		@PostMapping("/delete")
		public String deletEmployee(@RequestParam("empId") Integer empId) {
			 empService1.deleteEmployeeById(empId);
			 return "info";
		}
		
			
		@PostMapping("/update")
	    public String updateEmployee( Employee emp) {
		 empService1.updateEmployeeDetails1(emp); 
		 return "home"; 
		 }
			 
		
		 
}