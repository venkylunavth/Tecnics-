package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.model.Employee;

@Service
public class EmpService {
	
	@Autowired
	private EmployeeRepository empDao;
	
	// create 
	public Employee createEmployee(@RequestBody Employee emp) {
		 
		return empDao.save(emp);	
	}
	
	//get single emp detail
	 public Optional<Employee> getEmployee(int empId) {
		 return  empDao.findById(empId);
		 
	 }
	 
	 //get all emp details
	 public List<Employee> getEmployees(){
		 return (List<Employee>) empDao.findAll();
	 }
	
	 //delete emp by Id 
	 public String deleteEmployeeById(int empId) {
		 Optional<Employee> empId1 = empDao.findById(empId);
		 if(empId1.isPresent()) {
			 empDao.deleteById(empId);
			 return "employee is deleted successfully: "+empId;
		 }else {
			 return "Employee is doesnot exists "+empId;
		 }
	 }

	public void updateEmployeeDetails(Employee emp) {
		// TODO Auto-generated method stub
		
	}
	
	
	 
		
		/*
		 * //Update public 
		 * Employee updateEmployee(Employee employee) { 
		 * long Id =employee.getId();//104
		 *  Employee emp = dao.getById(Id);
		 * emp.setFirstName(employee.getFirstName());
		 * emp.setLastName(employee.getLastName());
		 * emp.setEmailId(employee.getEmailId()); return dao.save(emp);
		 * 
		 * }
		 */
	 
		
		
		//update employee 
	
	     public Employee updateEmployeeDetails1( Employee emp) {
	    int empId = emp.getEmpId();
		 Employee emp1 = empDao.getById(empId);
		 emp1.setEmpName(emp.getEmpName()); 
		 emp1.setEmpMail(emp.getEmpMail()); 
		 emp1.setEmpPhn(emp.getEmpPhn());
		 emp1.setDept(emp.getDept()); 
		 return empDao.save(emp1); 
		 }
		

	
}