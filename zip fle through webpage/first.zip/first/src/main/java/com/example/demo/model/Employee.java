package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;





@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "employee_new_table")
public class Employee {
	
	@Id
	
	private int empId; 
	
	@NotNull
    @Pattern(regexp="^[a-zA-Z]*$",message="name must letters")
	private String empName;
	
	@Email
	@NotEmpty(message = "Email cannot be empty")
	private String empMail;
   
	@NotNull
	@Pattern(regexp="^[0-9]*$")
	@Size(min=10, max=10, message = "Phone number must contain 10 digits")
	private String  empPhn;
	
	@NotNull(message = "please enter department")
	@Pattern(regexp="^[a-zA-Z]*$")
	private String dept;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpMail() {
		return empMail;
	}

	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}

	public String getEmpPhn() {
		return empPhn;
	}

	public void setEmpPhn(String empPhn) {
		this.empPhn = empPhn;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}
	public Employee(int empId, @NotNull @Pattern(regexp = "^[a-zA-Z]*$", message = "name must letters") String empName,
			@Email @NotEmpty(message = "Email cannot be empty") String empMail,
			@NotNull @Pattern(regexp = "^[0-9]*$") @Size(min = 10, max = 10, message = "Phone number must contain 10 digits") String empPhn,
			@NotNull(message = "please enter department") @Pattern(regexp = "^[a-zA-Z]*$") String dept) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empMail = empMail;
		this.empPhn = empPhn;
		this.dept = dept;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empMail=" + empMail + ", empPhn=" + empPhn
				+ ", dept=" + dept + "]";
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee findByDept(String dept) {
		// TODO Auto-generated method stub
		return null;
	}

	



}